# .1.3.6.1.2.1.2.2.1.7 (.*) disable port
# 1.3.6.1.4.1.890.1.5.8.19.18.1.1 arptable

use threads;
use strict;
use warnings;
 
use Net::SNMP qw(:snmp);