use IO::Async::Timer::Absolute;
 
use POSIX qw( mktime );
 
use IO::Async::Loop;
my $loop = IO::Async::Loop->new;
 
my @time = gmtime;
 
my $timer = IO::Async::Timer::Absolute->new(
   time => mktime( 0, 0, 0, $time[3]+1, $time[4], $time[5] ),
 
   on_expire => sub { 
      print "It's midnight\n";
      $loop->stop;
   },
);
 
$loop->add( $timer );
 
$loop->run;